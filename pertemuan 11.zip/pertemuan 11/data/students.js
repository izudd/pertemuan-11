// data students
const students = ["Mikel", "Hannah", "Jonan"];

// export students
module.exports = students;